/*import java.util.ArrayList;

public class Main {
	
	public Main() {

	public void main(String[] args) {
		
		int index = 1;
		
		ArrayList<Bike> bikeList = new ArrayList<Bike>();
		
		bikeList.add(new Bike("blue", 12, 56));
		bikeList.add(new Bike("green", 13, 444));
		bikeList.add(new Bike("black", 14, 500));
		bikeList.add(new Bike("silver", 18, 60));
		bikeList.add(new Bike("grey", 10, 80));
		bikeList.add(new Bike("pink", 2, 860));
		bikeList.add(new Bike("brown", 5, 500));
		bikeList.add(new Bike("orange", 22, 89));
		bikeList.add(new Bike("purple", 19, 76));
		bikeList.add(new Bike("white", 3, 600));
		
		
		for (int i = 0; i < bikeList.size(); i++) {
			
			System.out.println("nr:" + (index++) + " " + bikeList.get(i).getColor() + " " + bikeList.get(i).getSize()
					+ " " + bikeList.get(i).getPrice());

		}

	}

}
}
*/