
public class Dog {

	//variabel
	private String name;
	
	//konstruktor
	public Dog (String name) {
		this.name = name;

		}
	
	//getter
	public String getDogName(){
		return this.name;
	}

	
}
